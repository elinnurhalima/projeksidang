<?php
if (!session_id()) session_start();

require_once '../App/init.php';

$app = new App;
