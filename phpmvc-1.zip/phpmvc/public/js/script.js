$(function () {

  $('.tombolTambahData').on('click', function () {
    $('#judulModalLable').html('Tambah Data Siswa');
    $('.modal-footer button[type=submit]').html('Tambah Data');
    $('.modal-body form').attr('action', 'http://localhost:80/phpmvc/public/siswa/ubah')
  });

  $('.tampilModalUbah').on('click', function () {
    console.log('ok');

    $('#judulModalLabel').html('Ubah Data Siswa');
    $('.modal-footer button[type=submit]').html('Ubah Data');

    const id = $(this).data('id');

    $.ajax({
      url: 'http://localhost:80/phpmvc/public/siswa/getubah',
      data: { id: id },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        $('#nama').val(data.nama);
        $('#nrp').val(data.nrp);
        $('#email').val(data.email);
        $('#jurusan').val(data.jurusan);
        $('#jurusan').val(data.jurusan);
      }
    });

  });

});