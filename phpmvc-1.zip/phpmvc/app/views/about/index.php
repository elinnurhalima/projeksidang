<div class="container">
	<h1 class="mt-4 mb-4">Tentang Saya</h1>
	<img src="<?= BASEURL; ?>/img/Elin.jpg" alt="Elin" width="200" class="rounded-circle shadow mb-4">
	<p>Halo, nama saya <?= $data['nama']; ?> umur saya <?= $data['umur']; ?> tahun, saya adalah seorang <?= $data['pekerjaan']; ?>.</p>

</div>