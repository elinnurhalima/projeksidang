<div class="container">
	<div class="jumbotron mt-4">
		<h1 class="display-4">Selamat Datang di Website Input Data</h1>
		<p class="lead">Halo, nama saya <?= $data['nama']; ?></p>
		<hr class="my-4">
		<p>Bagian admin yang mengurusi input data siswa.</p>
	</div>


</div>