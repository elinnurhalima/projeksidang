<?php  

class User_model {
	private $nama = 'Eyinn';

	public function getUser()
	{
		return $this->nama;
	}
}